require('../models/database');
const Category = require('../models/Category')
const Recipe = require('../models/Recipe')
const User = require('../models/User')
const bcrypt = require('bcryptjs');
const { registrationValidation, loginValidation } = require('../middleware/validation.js')


/**
 * Get /
 * Homepage
 */

exports.homepage = async(req,res) => {
    try {

    const limitNumber = 5;
    const categories = await Category.find({}).limit(limitNumber);
    const latest = await Recipe.find({}).sort({_id: -1}).limit(limitNumber);
    const luzon = await Recipe.find({ 'category': 'Luzon' }).limit(limitNumber);
    const visayas = await Recipe.find({ 'category': 'Visayas' }).limit(limitNumber);
    const mindanao = await Recipe.find({ 'category': 'Mindanao' }).limit(limitNumber);

    

    const food = { latest, luzon, visayas, mindanao }; 

    res.render('index', { title: 'Cooking Blog - Home', categories, food });
    } catch (error) {
        res.status(500).send({message: error.message || "Error Occured"});
    }
}

/**
 * Get /guest
 * Homepage
 */

 exports.signInGuest = async(req,res) => {
    try {

    const limitNumber = 5;
    const categories = await Category.find({}).limit(limitNumber);
    const latest = await Recipe.find({}).sort({_id: -1}).limit(limitNumber);
    const luzon = await Recipe.find({ 'category': 'Luzon' }).limit(limitNumber);
    const visayas = await Recipe.find({ 'category': 'Visayas' }).limit(limitNumber);
    const mindanao = await Recipe.find({ 'category': 'Mindanao' }).limit(limitNumber);

    

    const food = { latest, luzon, visayas, mindanao }; 

    res.render('index-guest', { title: 'Cooking Blog - Home', categories, food});
    } catch (error) {
        res.status(500).send({message: error.message || "Error Occured"});
    }
}







/**
 * Get / categories
 * Categories
 */

 exports.exploreCategories = async(req,res) => {
    try {

    const limitNumber = 20;
    const categories = await Category.find({}).limit(limitNumber);
    
    res.render('categories', { title: 'Cooking Blog - Categories', categories });
    } catch (error) {
        res.status(500).send({message: error.message || "Error Occured"});
    }
}

/**
 * Get / categories-guest
 * Categories
 */

 exports.exploreCategoriesGuest = async(req,res) => {
    try {

    const limitNumber = 20;
    const categories = await Category.find({}).limit(limitNumber);
    
    res.render('categories-guest', { title: 'Cooking Blog - Categories', categories });
    } catch (error) {
        res.status(500).send({message: error.message || "Error Occured"});
    }
}




/**
 * Get / categories/:id
 * Categories byID
 */

 exports.exploreCategoriesById = async(req,res) => {
    try {

    let categoryId = req.params.id
    const limitNumber = 20;
    const categoryById = await Recipe.find({'category': categoryId}).limit(limitNumber);
    
    res.render('categories', { title: 'Cooking Blog - Categories', categoryById });
    } catch (error) {
        res.status(500).send({message: error.message || "Error Occured"});
    }
}

/**
 * Get / categories-guest/:id
 * Categories byID
 */

 exports.exploreCategoriesGuestById = async(req,res) => {
    try {

    let categoryId = req.params.id
    const limitNumber = 20;
    const categoryById = await Recipe.find({'category': categoryId}).limit(limitNumber);
    
    res.render('categories-guest', { title: 'Cooking Blog - Categories', categoryById });
    } catch (error) {
        res.status(500).send({message: error.message || "Error Occured"});
    }
}



/**
 * Get /recipe/:id
 * REcipe
 */

 exports.exploreRecipe = async(req,res) => {
    try {
    let recipeId= req.params.id;
    const recipe = await Recipe.findById(recipeId);
    res.render('recipe', { title: 'Cooking Blog - Recipe', recipe });
    } catch (error) {
        res.status(500).send({message: error.message || "Error Occured"});
    }
}



/**
 * Get /recipe-guest/:id
 * REcipe
 */

 exports.exploreRecipeGuest = async(req,res) => {
    try {
    let recipeId= req.params.id;
    const recipe = await Recipe.findById(recipeId);
    res.render('recipe-guest', { title: 'Cooking Blog - Recipe', recipe });
    } catch (error) {
        res.status(500).send({message: error.message || "Error Occured"});
    }
}



/**
 * Post /search
 * Search
 */
 exports.searchRecipe = async(req,res) => {
    try {
        let searchTerm = req.body.searchTerm;
        let recipe = await Recipe.find( {$text: { $search: searchTerm, $diacriticSensitive: true}});
        res.render('search', { title: 'Cooking Blog - Search', recipe });
    } catch (error) {
        res.status(500).send({message: error.message || "Error Occured"});
    }
 }

 /**
 * Post /search-guest
 * Search
 */
  exports.searchRecipeGuest = async(req,res) => {
    try {
        let searchTerm = req.body.searchTerm;
        let recipe = await Recipe.find( {$text: { $search: searchTerm, $diacriticSensitive: true}});
        res.render('search-guest', { title: 'Cooking Blog - Search', recipe });
    } catch (error) {
        res.status(500).send({message: error.message || "Error Occured"});
    }
 }


 /**
 * Get /explore-latest
 * Explore Latest
 */

  exports.exploreLatest = async(req,res) => {
    try {
        const limitNumber = 20;
        const recipe = await Recipe.find({}).sort({_id: -1}).limit(limitNumber);
        res.render('explore-latest', { title: 'Cooking Blog - Explore-Latest', recipe });
    } catch (error) {
        res.status(500).send({message: error.message || "Error Occured"});
    }
}

 /**
 * Get /explore-latest-guest
 * Explore Latest
 */

  exports.exploreLatestGuest = async(req,res) => {
    try {
        const limitNumber = 20;
        const recipe = await Recipe.find({}).sort({_id: -1}).limit(limitNumber);
        res.render('explore-latest-guest', { title: 'Cooking Blog - Explore-Latest', recipe });
    } catch (error) {
        res.status(500).send({message: error.message || "Error Occured"});
    }
}



 /**
 * Get /explore-random
 * Explore Random as JSON
 */

  exports.exploreRandom = async(req,res) => {
    try {
        let count = await Recipe.find().countDocuments();
        let random = Math.floor(Math.random() * count);
        let recipe = await Recipe.findOne().skip(random).exec();
        res.render('explore-random', { title: 'Cooking Blog - Explore-Random', recipe });
    } catch (error) {
        res.status(500).send({message: error.message || "Error Occured"});
    }
}

 /**
 * Get /explore-random-guest
 * Explore Random as JSON
 */

  exports.exploreRandomGuest = async(req,res) => {
    try {
        let count = await Recipe.find().countDocuments();
        let random = Math.floor(Math.random() * count);
        let recipe = await Recipe.findOne().skip(random).exec();
        res.render('explore-random-guest', { title: 'Cooking Blog - Explore-Random', recipe });
    } catch (error) {
        res.status(500).send({message: error.message || "Error Occured"});
    }
}




/**
 * Get /submit-recipe
 * Submit Recipe
 */

 exports.submitRecipe = async(req,res) => {
    const infoErrorsObj = req.flash('infoErrors');
    const infoSubmitsObj = req.flash('infoSubmit');
    res.render('submit-recipe', { title: 'Cooking Blog - Submit Recipe', infoErrorsObj, infoSubmitsObj });

}

/**
 * post /submit-recipe
 * Submit Recipe
 */

 exports.submitRecipeOnPost = async(req,res) => {
    try {

        let imageUploadFile;
        let uploadPath;
        let newImageName;
        
        if (!req.files || Object.keys(req.files).length === 0) {
            console.log('No Files where uploaded.');

        } else {
            imageUploadFile = req.files.image;
            newImageName = Date.now() + imageUploadFile.name;

            uploadPath = require('path').resolve('./') + '/public/uploads/' + newImageName;

            imageUploadFile.mv(uploadPath, function(err){
                if(err) return res.satus(500).send(err);
              })
        }


        const newRecipe = new Recipe({
            name: req.body.name,
            description: req.body.description,
            email: req.body.email,
            ingredients: req.body.ingredients,
            category: req.body.category,
            image: newImageName
        });

        await newRecipe.save();

        req.flash('infoSubmit', 'Recipe has been Added')
        res.redirect('/submit-recipe');
        
    } catch (error) {
        req.flash('infoErrors', error)
        res.redirect('/submit-recipe')
    }
}


/**
 * Get /update-recipe/:id
 * Update Recipe
 */

 exports.updateRecipe = async(req,res) => {
    try {
        
        let recipeId= req.params.id;
        const recipe = await Recipe.findById(recipeId);
        res.render('update-recipe', { title: 'Cooking Blog - Update Recipe' , recipe});
        } catch (error) {
            res.status(500).send({message: error.message || "Error Occured"});
        }
}



/**
 * post /update-recipe/:id
 * Update Recipe on Post
 */

 exports.updateRecipeOnPost = async(req,res) => {
    

    try {

        const {id} = req.params;
        const {name, description, email, ingredients, category, image} = req.body;
        const update = await Recipe.findByIdAndUpdate(id, {name, description, email, ingredients, category});
        res.render('updated-recipe', { title: 'Cooking Blog - Updated Recipe' , update});
    } catch (error) {
        res.status(500).send(error)
        
    }
   
}


/**
 * get /delete-recipe/:id
 * Delete Recipe on Post
 */

 exports.deleteRecipeOnPost = async(req,res) => {
    

    try {

        const {id} = req.params;
        const {name, description, email, ingredients, category, image} = req.body;
        const deleteId = await Recipe.findByIdAndDelete(id, {name, description, email, ingredients, category, image});
        res.render('deleted-recipe', { title: 'Cooking Blog - Delete Recipe' , deleteId});
    } catch (error) {
        res.status(500).send(error)
        
    }
   
}


/**
 * Get /signUpPage
 * Sign-up
 */

 exports.signUpPage =  async  (req,res) => {
    const infoErrorsObj = req.flash('infoErrors');
    const infoSubmitsObj = req.flash('infoSubmit');
    res.render('sign-up', { title: 'Cooking Blog - Sign-up', infoErrorsObj, infoSubmitsObj });
 }




/**
 * Post /sign-up
 * Sign-up
 */

exports.signUpAdd = async(req,res) => {
    const { error } = +(req.body);
    // res.send(error.details[0].message)
    //check if the save collection is valid
    if (error) return res.status(400).send(error.details[0].message);
    //check if username Exist
    const userName = await User.findOne ({ name: req.body.name });
    if (userName) return res.status(400).send('Username already exists');
    //check if email Exist
    const userEmail = await User.findOne ({ email: req.body.email });
    if (userEmail) return res.status(400).send('Email already exists');
    //hash Password
    const salt = await bcrypt.genSalt(10);
    const hashedPass = await bcrypt.hash(req.body.password, salt);
   

   try {
        
       const newUser = new User({
           name: req.body.name,
           email: req.body.email,
           password: hashedPass
       });

       await newUser.save();

       req.flash('infoSubmit', 'Succesfully Signed Up')
       res.redirect('/sign-in');
       
   } catch (error) {
       req.flash('infoErrors', error)
       res.redirect('/sign-in')
   }
   
}


/**
 * Get /sign-in
 * Sign-in
 */

 exports.signInPage = async(req,res) => {
    const infoErrorsObj = req.flash('infoErrors');
    const infoSubmitsObj = req.flash('infoSubmit');
    res.render('sign-in', { title: 'Cooking Blog - Sign-in', infoErrorsObj, infoSubmitsObj });
 }


 /**
 * Post /sign-in
 * Sign-in
 */

  exports.signIn = async(req,res) => {
    
        const { error } = loginValidation(req.body);
    if (error) return res.status(400).send(error.details[0].message);
    //validate email
    const user = await User.findOne ({ email: req.body.email });
    if (!user) return res.status(400).send('Email not matched')
    //validate password
    const userPassword = await bcrypt.compare(req.body.password, user.password);
    if (!userPassword) return res.status(400).send('Invalid password')

    const limitNumber = 5;
    const categories = await Category.find({}).limit(limitNumber);
    const latest = await Recipe.find({}).sort({_id: -1}).limit(limitNumber);
    const luzon = await Recipe.find({ 'category': 'Luzon' }).limit(limitNumber);
    const visayas = await Recipe.find({ 'category': 'Visayas' }).limit(limitNumber);
    const mindanao = await Recipe.find({ 'category': 'Mindanao' }).limit(limitNumber);

    const food = { latest, luzon, visayas, mindanao };

    const email = req.body.email;
    let UserEmail = await User.find({'email': email});


    res.render('index', { title: 'Cooking Blog - Home' , UserEmail, categories, food })
        
   
    
}





    // try {

    //     const userEmail = await User.findOne({email: req.body.email});
    //     if( !userEmail) return res.status(400).send('Email not match')
    //     const userPass = await User.findOne({password: req.body.password});
    //     if( !userPass) return res.status(400).send('Password not match')

    //     res.redirect('/');

    // } catch (error) {
    //     res.status(500).send(error)
    // }

 





































//Update Recipe
// async function updateRecipe() {

//     try {
//         const res = await Recipe.updateOne( {name: 'new recipe with image'}, { name: 'NewRecipe Udated'});
//         res.n;
//         res.nmodified;
//     } catch (error) {
//         console.log(error);
//     }
// }
// updateRecipe()



// Delete Recipe
// async function deleteRecipe(){
//   try {
//     await Recipe.deleteOne({ name: 'New Recipe From Form' });
//   } catch (error) {
//     console.log(error);
//   }
// }
// deleteRecipe();
















//  exports.homepage = async(req,res) => {
//     res.render('index', {title: 'Cooking Blog -Home'});
//  }



// async function insertDymmyCategoryData() {

//     try {
//         await Category.insertMany([
//             {
//                 'name': 'Thai',
//                 'image': 'thai-food.jpg'
//             },
//             {
//                 'name': 'American',
//                 'image': 'american-food.jpg'
//             },
//             {
//                 'name': 'Chinese',
//                 'image': 'chinese-food.jpg'
//             },
//             {
//                 'name': 'Mexican',
//                 'image': 'mexican-food.jpg'
//             },
//             {
//                 'name': 'Indian',
//                 'image': 'indian-food.jpg'
//             },
//             {
//                 'name': 'Spanish',
//                 'image': 'spanish-food.jpg'
//             },
//         ]);
//     } catch (error) {
//         console.log('err', + error)
//     }
// }


// insertDymmyCategoryData();



// async function insertDymmyRecipeData(){
//   try {
//     await Recipe.insertMany([
//       { 
//         "name": "Recipe Name Goes Here",
//         "description": `Recipe Description Goes Here`,
//         "email": "recipeemail@raddy.co.uk",
//         "ingredients": [
//           "1 level teaspoon baking powder",
//           "1 level teaspoon cayenne pepper",
//           "1 level teaspoon hot smoked paprika",
//         ],
//         "category": "American", 
//         "image": "southern-friend-chicken.jpg"
//       },
//       { 
//         "name": "Recipe Name Goes Here",
//         "description": `Recipe Description Goes Here`,
//         "email": "recipeemail@raddy.co.uk",
//         "ingredients": [
//           "1 level teaspoon baking powder",
//           "1 level teaspoon cayenne pepper",
//           "1 level teaspoon hot smoked paprika",
//         ],
//         "category": "American", 
//         "image": "southern-friend-chicken.jpg"
//       },
//     ]);
//   } catch (error) {
//     console.log('err', + error)
//   }
// }

// insertDymmyRecipeData();

