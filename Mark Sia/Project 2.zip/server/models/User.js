const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    name: {
        type: String,
        max: 20,
        min: 5,
        required: 'This field is required.'
    },
    email: {
        type: String,
        max: 20,
        min: 5,
        required: 'This field is required.'
    },
    password: {
        type: String,
        max: 1050,
        min: 6,
        required: 'This field is required.'
    },
});

module.exports = mongoose.model('User', userSchema)