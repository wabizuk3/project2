const express = require('express');
const router = express.Router();
const recipeController = require('../controllers/recipeController');

/**
 * App Routes
 */
router.get('/sign-up', recipeController.signUpPage);
router.post('/sign-up', recipeController.signUpAdd);

router.get('/sign-in', recipeController.signInPage);
router.post('/sign-in', recipeController.signIn);

router.get('/guest', recipeController.signInGuest);
router.get('/categories-guest', recipeController.exploreCategoriesGuest);
router.get('/recipe-guest/:id', recipeController.exploreRecipeGuest);
router.get('/categories-guest/:id', recipeController.exploreCategoriesGuestById);
router.get('/explore-latest-guest', recipeController.exploreLatestGuest);
router.get('/explore-random-guest', recipeController.exploreRandomGuest);
router.post('/search-guest', recipeController.searchRecipeGuest);



router.get('/', recipeController.homepage);
router.get('/categories', recipeController.exploreCategories);
router.get('/recipe/:id', recipeController.exploreRecipe);
router.get('/categories/:id', recipeController.exploreCategoriesById);
router.post('/search', recipeController.searchRecipe);
router.get('/explore-latest', recipeController.exploreLatest);
router.get('/explore-random', recipeController.exploreRandom);
router.get('/submit-recipe', recipeController.submitRecipe);
router.post('/submit-recipe', recipeController.submitRecipeOnPost);
router.get('/update-recipe/:id', recipeController.updateRecipe);
router.post('/update-recipe/:id', recipeController.updateRecipeOnPost);
router.get('/delete-recipe/:id', recipeController.deleteRecipeOnPost);





module.exports= router;